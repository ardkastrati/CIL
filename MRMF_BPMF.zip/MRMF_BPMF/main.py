
from SGDCollaborativeRegressor import SGDCollaborativeRegressor
from bpmf import BPMF
from utils.evaluation import RMSE
import IOHelper
import numpy as np
from sklearn.model_selection import KFold

train_data_path = "data/data_train.csv"
test_data_path = "data/sampleSubmission.csv"

filename = "Biased_Bayesian_PMF.csv"
test_error = "test_error.txt"
D = 10000
N = 1000
# X, y = IOHelper.extract_training_scores(train_data_path, verbose=True)
print("Training data...")
data = IOHelper.numpy_training_data(train_data_path, verbose=True)
print("Implicit data...")
test_data = IOHelper.numpy_training_data(test_data_path, verbose=True)



def cross_validate_BPMF():

    rand_state = np.random.RandomState(0)
    n_user = D
    n_item = N
    n_features = [[2,3,5,8]]
    burn_in = 0
    eval_iters = 150
    rand_state.shuffle(data)

    for curr_n_feature in n_features:
        print("crossvalidating BPMF model...")
        print("Rank", curr_n_feature)

        skf = KFold(n_splits=10, shuffle=True, random_state=rand_state)
        for train_indices, validation_indices in skf.split(data):
            print("Test......")
            X_train = data[train_indices]
            X_validation = data[validation_indices]

            print("training size: %d" % X_train.shape[0])
            print("validation size: %d" % X_validation.shape[0])

            bpmf = BPMF(n_user=n_user, n_item=n_item, n_feature=curr_n_feature,max_rating=5., min_rating=1., seed=42, burn_in=burn_in)
            bpmf.fit(X_train, X_validation, test_data, n_iters=eval_iters)

def final_train_BPMF():
    rand_state = np.random.RandomState(42)
    n_user = D
    n_item = N
    n_features = [5, 10, 20, 30, 40, 50]
    burn_in = 250
    eval_iters = 700
    train_pct = 0.999
    rand_state.shuffle(data)
    train_size = int(train_pct * data.shape[0])
    train = data[:train_size]
    val = data[train_size:]

    print("training size: %d" % train.shape[0])
    print("validation size: %d" % val.shape[0])

    print("Rank", n_features)
    bpmf = BPMF(n_user=n_user, n_item=n_item, n_feature=n_features, max_rating=5., min_rating=1., seed=42, burn_in=burn_in)
    bpmf.fit(train, val, test_data, n_iters=eval_iters)
    IOHelper.numpy_output_submission(bpmf.predictions, filename, test_data, verbose=True)


def main():

    cross_validate_BPMF()
    #final_train_BPMF()


if __name__=='__main__':
    main()
